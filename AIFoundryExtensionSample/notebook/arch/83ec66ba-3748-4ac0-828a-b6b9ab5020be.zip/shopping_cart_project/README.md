# Shopping Cart Project

## Description

Develop a shopping cart using Python. The shopping cart allows users to add and remove products.

## Features

- Get a list of beers using page offsets and limits.
- Get beer details by id.
- Search for beer by name, description, tagline, food pairings, and price.
- Create a list of products on the main page.
- Create a search bar to filter products.
- Jump to the description page when the user clicks on a product.
- (Optional) Slicer to filter products by price.
- Create a shopping cart.
  - Add products to the cart.
  - Remove products from the cart.
  - Calculate the total price of the products in the cart.

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```bash
python app/main.py
```
