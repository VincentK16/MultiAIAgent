from sqlalchemy import Column, Integer, String, Float
from .database import Base

class Beer(Base):
    __tablename__ = 'beers'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    description = Column(String, nullable=False)
    tagline = Column(String, nullable=False)
    food_pairings = Column(String, nullable=False)
    price = Column(Float, nullable=False)
