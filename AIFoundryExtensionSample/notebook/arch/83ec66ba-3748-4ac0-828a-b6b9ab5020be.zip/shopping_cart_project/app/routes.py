from flask import Blueprint, request, render_template, redirect, url_for
from .models import Beer
from .database import db_session

main = Blueprint('main', __name__)

@main.route('/')
def index():
    beers = Beer.query.all()
    return render_template('index.html', beers=beers)

@main.route('/beer/<int:beer_id>')
def beer_details(beer_id):
    beer = Beer.query.get(beer_id)
    return render_template('product_details.html', beer=beer)

@main.route('/search')
def search():
    query = request.args.get('q')
    beers = Beer.query.filter(Beer.name.contains(query) |
                              Beer.description.contains(query) |
                              Beer.tagline.contains(query) |
                              Beer.food_pairings.contains(query)).all()
    return render_template('search_results.html', beers=beers)

@main.route('/cart')
def cart():
    # Logic for displaying the cart
    return render_template('cart.html')

@main.route('/add_to_cart/<int:beer_id>')
def add_to_cart(beer_id):
    # Logic for adding a beer to the cart
    return redirect(url_for('main.cart'))

@main.route('/remove_from_cart/<int:beer_id>')
def remove_from_cart(beer_id):
    # Logic for removing a beer from the cart
    return redirect(url_for('main.cart'))
