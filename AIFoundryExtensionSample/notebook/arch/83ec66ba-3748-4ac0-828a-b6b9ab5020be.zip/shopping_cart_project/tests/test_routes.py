import unittest
from app import create_app

class TestRoutes(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.client = self.app.test_client()

    def test_index_route(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)

    def test_beer_details_route(self):
        response = self.client.get('/beer/1')
        self.assertEqual(response.status_code, 200)

    def test_search_route(self):
        response = self.client.get('/search?q=Test')
        self.assertEqual(response.status_code, 200)

    def test_cart_route(self):
        response = self.client.get('/cart')
        self.assertEqual(response.status_code, 200)

if __name__ == '__main__':
    unittest.main()
