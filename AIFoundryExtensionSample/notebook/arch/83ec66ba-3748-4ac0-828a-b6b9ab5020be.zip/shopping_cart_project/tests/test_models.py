import unittest
from app.models import Beer

class TestBeerModel(unittest.TestCase):
    def test_beer_model(self):
        beer = Beer(name="Test Beer", description="Test Description", tagline="Test Tagline", food_pairings="Test Food Pairings", price=10.0)
        self.assertEqual(beer.name, "Test Beer")
        self.assertEqual(beer.description, "Test Description")
        self.assertEqual(beer.tagline, "Test Tagline")
        self.assertEqual(beer.food_pairings, "Test Food Pairings")
        self.assertEqual(beer.price, 10.0)

if __name__ == '__main__':
    unittest.main()
